This is an windows form application written with c# for the purpose of managing huge counts of customer information data and sending e-mails to your customer. If you want me to add new features to the application in order to your 
needs you can contact with me at ozan.ozenoglu@gmail.com 

This application is free to use .


C# ile yazilmis windows form uygulamasi y�ksek sayidaki m�steri bilgilerini y�netebilmeniz ve mail atabilmenize yarar. Eger uygulamayi ihtiya�lariniz dogrultusunda gelistirmemi isterseniz bana ozan.ozenoglu@gmail.com adresinden ulasabilirsiniz.

Bu uygulamayi �cretsiz olarak kullanabilirsiniz.



